import './NewProduct.css'
import ProductForm from './ProductForm';

function NewProduct(props) {
    return (
        <div>
            <ProductForm></ProductForm>
        </div>
    )
}

export default NewProduct;